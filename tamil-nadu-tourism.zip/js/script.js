document.getElementById("loginForm").addEventListener("submit", async function(e) {
    e.preventDefault();

    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value.trim();
    const message = document.getElementById("message");

    try {
        const response = await fetch("/api/login", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({email, password})
        });

        if (response.ok) {
            const data = await response.json();
            if (data.success) {
                sessionStorage.setItem("loggedIn", "true");
                window.location.href = "home.html";
                return;
            } else {
                message.textContent = "Invalid email or password";
                return;
            }
        }
    } catch (error) {
        // Fallback for local static execution without backend server
    }

    if (email && password) {
        sessionStorage.setItem("loggedIn", "true");
        window.location.href = "home.html";
    } else {
        message.textContent = "Invalid email or password";
    }
});
