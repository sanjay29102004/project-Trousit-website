const places = [
    {
        district: "Salem",
        name: "Yercaud",
        description: "Beautiful hills, lake and nature.",
        hotel: "Yercaud Hill Resort",
        price: 2000,
        image: "images/yercaud.png"
    },
    {
        district: "Chennai",
        name: "Marina Beach",
        description: "Famous urban beach along the Bay of Bengal in Chennai.",
        hotel: "Marina Seafront Stay",
        price: 2500,
        image: "images/yercaud.png"
    },
    {
        district: "Nilgiris",
        name: "Ooty",
        description: "Queen of Hill Stations known for tea gardens and botanical parks.",
        hotel: "Nilgiri Valley Resort",
        price: 3200,
        image: "images/yercaud.png"
    },
    {
        district: "Dindigul",
        name: "Kodaikanal",
        description: "Misty cliffs, star-shaped lake, and lush pine forests.",
        hotel: "Kodai Lakeview Inn",
        price: 2800,
        image: "images/yercaud.png"
    },
    {
        district: "Madurai",
        name: "Meenakshi Amman Temple",
        description: "Historic temple city celebrated for Dravidian architecture and culture.",
        hotel: "Heritage Temple Residency",
        price: 2200,
        image: "images/yercaud.png"
    },
    {
        district: "Kanyakumari",
        name: "Kanyakumari",
        description: "Southernmost tip of mainland India with sunrise and sunset views.",
        hotel: "Cape Ocean View Hotel",
        price: 2400,
        image: "images/yercaud.png"
    }
];

const container = document.getElementById("places");

if (container) {
    places.forEach((place) => {
        const card = document.createElement("div");
        card.className = "card";
        card.innerHTML = `
            <img src="${place.image}" alt="${place.name}">
            <div class="card-content">
                <h3>${place.name}</h3>
                <div class="district">📍 ${place.district} District</div>
                <p>${place.description}</p>
                <p><strong>Stay:</strong> ${place.hotel}</p>
                <div class="price">₹${place.price} / night</div>
                <a href="#" onclick="alert('Booking request received for ${place.name} (${place.hotel})!'); return false;">Book Now</a>
            </div>
        `;
        container.appendChild(card);
    });
}
